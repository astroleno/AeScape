popup.js:327 Applied theme gradient: linear-gradient(135deg, rgba(103, 58, 183, 0.15) 0%, rgba(156, 39, 176, 0.1) 100%)
popup.js:327 Applied theme gradient: linear-gradient(135deg, rgba(103, 58, 183, 0.15) 0%, rgba(156, 39, 176, 0.1) 100%)
popup.js:327 Applied theme gradient: linear-gradient(135deg, rgba(103, 58, 183, 0.15) 0%, rgba(156, 39, 176, 0.1) 100%)
Warning: Don’t paste code into the DevTools Console that you don’t understand or haven’t reviewed yourself. This could allow attackers to steal your identity or take control of your computer. Please type ‘allow pasting’ below and press Enter to allow pasting.
Warning: Don’t paste code into the DevTools Console that you don’t understand or haven’t reviewed yourself. This could allow attackers to steal your identity or take control of your computer. Please type ‘allow pasting’ below and press Enter to allow pasting.
allow pasting
document.body.classList.contains('popup-body'
VM109:1 Uncaught SyntaxError: missing ) after argument list
chrome.storage.local.get('currentThemeData').then(x=>console.log(x))
Promise {<pending>}
VM113:1 {currentThemeData: {…}}
getComputedStyle(document.body).backgroundImage
'linear-gradient(135deg, rgba(103, 58, 183, 0.15) 0%, rgba(156, 39, 176, 0.1) 100%)'
