content.js:886 [AeScape] 准备初始化悬浮球
content.js:32 [AeScape] 悬浮球系统初始化开始
content.js:83 [AeScape] URL检查: https://learn.microsoft.com/en-us/sysinternals/downloads/procmon, 应排除: false
content.js:916 [AeScape] 内容脚本已加载
content.js:91 [AeScape] 用户设置检查: true
content.js:106 [AeScape] 等待主题系统... 第1次尝试
content.js:109 [AeScape] 主题系统已加载
content.js:129 [AeScape] 创建悬浮球DOM
content.js:276 [AeScape] 应用默认主题
content.js:284 [AeScape] 使用统一主题系统: {primary: 'rgb(63, 81, 181)', secondary: 'rgb(92, 107, 192)', accent: 'rgb(149, 117, 205)', gradient: 'linear-gradient(135deg, rgb(31, 40, 91) 0%, rgb(46, 54, 96) 100%)', text: 'rgba(255, 255, 255, 0.98)'}
content.js:314 [AeScape] 已设置默认天气图标
content.js:182 [AeScape] 悬浮球DOM已添加到页面
content.js:319 [AeScape] 开始加载天气数据
content.js:362 [AeScape] 更新悬浮球显示: {location: {…}, weather: {…}, env: {…}, timestamp: 1756138252088}
content.js:384 [AeScape] 更新主题
content.js:338 [AeScape] 天气数据加载成功: {location: {…}, weather: {…}, env: {…}, timestamp: 1756138252088}
content.js:399 [AeScape] 主题已更新（来自背景服务）: {gradient: 'linear-gradient(135deg, rgb(31, 40, 91) 0%, rgb(46, 54, 96) 100%)', text: 'rgba(255, 255, 255, 0.98)'}
content.js:347 [AeScape] 位置数据加载成功: {country: '', lat: 31.2322758, lon: 121.4692071, name: 'Shanghai'}
content.js:66 [AeScape] 悬浮球系统初始化完成
index-docs.js:10726 [Violation] Added non-passive event listener to a scroll-blocking 'touchstart' event. Consider marking event handler as 'passive' to make the page more responsive. See https://www.chromestatus.com/feature/5745543795965952
connectedCallback @ index-docs.js:10726
__insert @ index-docs.js:17
__commitNode @ index-docs.js:17
__commitTemplateResult @ index-docs.js:17
commit @ index-docs.js:17
x @ index-docs.js:17
zDe @ index-docs.js:2899
await in zDe
oge @ index-docs.js:2899
(anonymous) @ index-docs.js:10726
(anonymous) @ index-docs.js:10726
index-docs.js:10726 [Violation] Added non-passive event listener to a scroll-blocking 'touchstart' event. Consider marking event handler as 'passive' to make the page more responsive. See https://www.chromestatus.com/feature/5745543795965952
connectedCallback @ index-docs.js:10726
__insert @ index-docs.js:17
__commitNode @ index-docs.js:17
__commitTemplateResult @ index-docs.js:17
commit @ index-docs.js:17
x @ index-docs.js:17
zDe @ index-docs.js:2899
await in zDe
oge @ index-docs.js:2899
(anonymous) @ index-docs.js:10726
(anonymous) @ index-docs.js:10726
index-docs.js:10726 [Violation] Added non-passive event listener to a scroll-blocking 'touchstart' event. Consider marking event handler as 'passive' to make the page more responsive. See https://www.chromestatus.com/feature/5745543795965952
connectedCallback @ index-docs.js:10726
__insert @ index-docs.js:17
__commitNode @ index-docs.js:17
__commitTemplateResult @ index-docs.js:17
commit @ index-docs.js:17
x @ index-docs.js:17
zDe @ index-docs.js:2899
await in zDe
oge @ index-docs.js:2899
(anonymous) @ index-docs.js:10726
(anonymous) @ index-docs.js:10726
index-docs.js:10726 [Violation] Added non-passive event listener to a scroll-blocking 'touchstart' event. Consider marking event handler as 'passive' to make the page more responsive. See https://www.chromestatus.com/feature/5745543795965952
connectedCallback @ index-docs.js:10726
__insert @ index-docs.js:17
__commitNode @ index-docs.js:17
__commitTemplateResult @ index-docs.js:17
commit @ index-docs.js:17
x @ index-docs.js:17
zDe @ index-docs.js:2899
await in zDe
oge @ index-docs.js:2899
(anonymous) @ index-docs.js:10726
(anonymous) @ index-docs.js:10726
content.js:2263 Cache loaded from storage: 172 items
content.js:2200 Preloaded 179 local cards to cache
content.js:2304 Cleaned up 84 duplicate cards
content.js:2473 Starting periodic update mechanism...
content.js:2485 Periodic update started with 180s interval
content.js:267 [AeScape] 位置已保存: {left: 1350, top: 810}
content.js:199 [AeScape] 悬浮球被点击
content.js:475 [AeScape] 切换面板显示状态
content.js:485 [AeScape] 显示详情面板
content.js:2310 Force preloading more content...
content.js:2333 Force preloading quotes: 19 cards needed
content.js:2333 Force preloading facts: 19 cards needed
procmon:1 The resource https://learn.microsoft.com/en-us/media/ask-learn/check-for-accuracy-base.png was preloaded using link preload but not used within a few seconds from the window's load event. Please make sure it has an appropriate `as` value and it is preloaded intentionally.
procmon:1 The resource https://learn.microsoft.com/en-us/media/ask-learn/meet-ask-learn-base.png was preloaded using link preload but not used within a few seconds from the window's load event. Please make sure it has an appropriate `as` value and it is preloaded intentionally.
content.js:1126 Numbers API failed, trying API Ninjas as fallback: AbortError: signal is aborted without reason
    at content.js:1101:53
fetchFactCards @ content.js:1126
await in fetchFactCards
fetchNewCardFromAPI @ content.js:957
forcePreloadMoreContent @ content.js:2376
(anonymous) @ content.js:352
setTimeout
init @ content.js:351
await in init
WaitWiki @ content.js:306
(anonymous) @ content.js:2593
content.js:1133  GET https://api.api-ninjas.com/v1/facts?limit=1 400 (Bad Request)
fetchFactCards @ content.js:1133
await in fetchFactCards
fetchNewCardFromAPI @ content.js:957
forcePreloadMoreContent @ content.js:2376
(anonymous) @ content.js:352
setTimeout
init @ content.js:351
await in init
WaitWiki @ content.js:306
(anonymous) @ content.js:2593
content.js:1156 API Ninjas also failed, using local fallback: Error: HTTP 400
    at WaitWiki.fetchFactCards (content.js:1142:17)
    at async WaitWiki.fetchNewCardFromAPI (content.js:957:19)
    at async WaitWiki.forcePreloadMoreContent (content.js:2376:15)
fetchFactCards @ content.js:1156
await in fetchFactCards
fetchNewCardFromAPI @ content.js:957
forcePreloadMoreContent @ content.js:2376
(anonymous) @ content.js:352
setTimeout
init @ content.js:351
await in init
WaitWiki @ content.js:306
(anonymous) @ content.js:2593
content.js:1103  GET https://numbersapi.com/random/trivia net::ERR_CONNECTION_CLOSED
fetchFactCards @ content.js:1103
fetchNewCardFromAPI @ content.js:957
forcePreloadMoreContent @ content.js:2376
await in forcePreloadMoreContent
(anonymous) @ content.js:352
setTimeout
init @ content.js:351
await in init
WaitWiki @ content.js:306
(anonymous) @ content.js:2593
content.js:1126 Numbers API failed, trying API Ninjas as fallback: TypeError: Failed to fetch
    at WaitWiki.fetchFactCards (content.js:1103:30)
    at WaitWiki.fetchNewCardFromAPI (content.js:957:30)
    at WaitWiki.forcePreloadMoreContent (content.js:2376:26)
fetchFactCards @ content.js:1126
await in fetchFactCards
fetchNewCardFromAPI @ content.js:957
forcePreloadMoreContent @ content.js:2376
await in forcePreloadMoreContent
(anonymous) @ content.js:352
setTimeout
init @ content.js:351
await in init
WaitWiki @ content.js:306
(anonymous) @ content.js:2593
content.js:1133  GET https://api.api-ninjas.com/v1/facts?limit=1 400 (Bad Request)
fetchFactCards @ content.js:1133
await in fetchFactCards
fetchNewCardFromAPI @ content.js:957
forcePreloadMoreContent @ content.js:2376
await in forcePreloadMoreContent
(anonymous) @ content.js:352
setTimeout
init @ content.js:351
await in init
WaitWiki @ content.js:306
(anonymous) @ content.js:2593
content.js:1156 API Ninjas also failed, using local fallback: Error: HTTP 400
    at WaitWiki.fetchFactCards (content.js:1142:17)
    at async WaitWiki.fetchNewCardFromAPI (content.js:957:19)
    at async WaitWiki.forcePreloadMoreContent (content.js:2376:15)
fetchFactCards @ content.js:1156
await in fetchFactCards
fetchNewCardFromAPI @ content.js:957
forcePreloadMoreContent @ content.js:2376
await in forcePreloadMoreContent
(anonymous) @ content.js:352
setTimeout
init @ content.js:351
await in init
WaitWiki @ content.js:306
(anonymous) @ content.js:2593
procmon:1 The resource https://learn.microsoft.com/en-us/media/ask-learn/check-for-accuracy-base.png was preloaded using link preload but not used within a few seconds from the window's load event. Please make sure it has an appropriate `as` value and it is preloaded intentionally.
procmon:1 The resource https://learn.microsoft.com/en-us/media/ask-learn/meet-ask-learn-base.png was preloaded using link preload but not used within a few seconds from the window's load event. Please make sure it has an appropriate `as` value and it is preloaded intentionally.
content.js:1126 Numbers API failed, trying API Ninjas as fallback: AbortError: signal is aborted without reason
    at content.js:1101:53
fetchFactCards @ content.js:1126
await in fetchFactCards
fetchNewCardFromAPI @ content.js:957
forcePreloadMoreContent @ content.js:2376
await in forcePreloadMoreContent
(anonymous) @ content.js:352
setTimeout
init @ content.js:351
await in init
WaitWiki @ content.js:306
(anonymous) @ content.js:2593
content.js:1133  GET https://api.api-ninjas.com/v1/facts?limit=1 400 (Bad Request)
fetchFactCards @ content.js:1133
await in fetchFactCards
fetchNewCardFromAPI @ content.js:957
forcePreloadMoreContent @ content.js:2376
await in forcePreloadMoreContent
(anonymous) @ content.js:352
setTimeout
init @ content.js:351
await in init
WaitWiki @ content.js:306
(anonymous) @ content.js:2593
content.js:1156 API Ninjas also failed, using local fallback: Error: HTTP 400
    at WaitWiki.fetchFactCards (content.js:1142:17)
    at async WaitWiki.fetchNewCardFromAPI (content.js:957:19)
    at async WaitWiki.forcePreloadMoreContent (content.js:2376:15)
fetchFactCards @ content.js:1156
await in fetchFactCards
fetchNewCardFromAPI @ content.js:957
forcePreloadMoreContent @ content.js:2376
await in forcePreloadMoreContent
(anonymous) @ content.js:352
setTimeout
init @ content.js:351
await in init
WaitWiki @ content.js:306
(anonymous) @ content.js:2593
content.js:2333 Force preloading advice: 19 cards needed
